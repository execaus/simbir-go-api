package repository

import (
	"context"
	"github.com/execaus/exloggo"
	"simbir-go-api/models"
	"simbir-go-api/pkg/repository/sqlnt"
	"simbir-go-api/queries"
	"time"
)

type RentPostgres struct {
	queries *queries.Queries
}

func (r *RentPostgres) Remove(id int32) error {
	if err := r.queries.RemoveRent(context.Background(), id); err != nil {
		exloggo.Error(err.Error())
		return err
	}

	return nil
}

func (r *RentPostgres) Update(rent *models.Rent) (*queries.Rent, error) {
	updatedRent, err := r.queries.UpdateRent(context.Background(), queries.UpdateRentParams{
		Account:   rent.Account,
		Transport: rent.Transport,
		TimeStart: rent.TimeStart,
		TimeEnd:   sqlnt.ToTimeNull(rent.TimeEnd),
		PriceUnit: rent.PriceUnit,
		PriceType: rent.PriceType,
		ID:        rent.ID,
	})
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return &updatedRent, nil
}

func (r *RentPostgres) End(id int32, timeEnd *time.Time) error {
	if err := r.queries.EndRent(context.Background(), queries.EndRentParams{
		TimeEnd: sqlnt.ToTimeNull(timeEnd),
		ID:      id,
	}); err != nil {
		exloggo.Error(err.Error())
		return err
	}

	return nil
}

func (r *RentPostgres) Create(rent *models.Rent) (*queries.Rent, error) {
	reposRent, err := r.queries.CreateRent(context.Background(), queries.CreateRentParams{
		Account:   rent.Account,
		Transport: rent.Transport,
		TimeStart: rent.TimeStart,
		TimeEnd:   sqlnt.ToTimeNull(rent.TimeEnd),
		PriceUnit: rent.PriceUnit,
		PriceType: rent.PriceType,
	})
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return &reposRent, nil
}

func (r *RentPostgres) IsExistCurrentRented(transportID int32) (bool, error) {
	isExist, err := r.queries.IsExistCurrentRent(context.Background(), transportID)
	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isExist, nil
}

func (r *RentPostgres) GetListFromUserID(userID, start, count int32) ([]queries.Rent, error) {
	rows, err := r.queries.GetRentsFromID(context.Background(), queries.GetRentsFromIDParams{
		Account: userID,
		Offset:  start,
		Limit:   count,
	})
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return rows, nil
}

func (r *RentPostgres) GetListFromTransportID(transportID, start, count int32) ([]queries.Rent, error) {
	rows, err := r.queries.GetRentsFromTransportID(context.Background(), queries.GetRentsFromTransportIDParams{
		Transport: transportID,
		Offset:    start,
		Limit:     count,
	})
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return rows, nil
}

func (r *RentPostgres) Get(id int32) (*queries.Rent, error) {
	row, err := r.queries.GetRent(context.Background(), id)
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return &row, err
}

func (r *RentPostgres) IsRenter(id int32, userID int32) (bool, error) {
	isRenter, err := r.queries.IsRenter(context.Background(), queries.IsRenterParams{
		ID:      id,
		Account: userID,
	})
	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isRenter, err
}

func (r *RentPostgres) IsExist(id int32) (bool, error) {
	isExist, err := r.queries.IsRentExist(context.Background(), id)
	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isExist, err
}

func (r *RentPostgres) IsRemoved(id int32) (bool, error) {
	isRemoved, err := r.queries.IsRentRemoved(context.Background(), id)
	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isRemoved, err
}

func NewRentPostgres(queries *queries.Queries) *RentPostgres {
	return &RentPostgres{queries: queries}
}
