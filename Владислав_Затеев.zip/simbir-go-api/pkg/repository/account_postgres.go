package repository

import (
	"context"
	"database/sql"
	"github.com/execaus/exloggo"
	"simbir-go-api/constants"
	"simbir-go-api/models"
	"simbir-go-api/queries"
)

type AccountPostgres struct {
	db      *sql.DB
	queries *queries.Queries
}

func (r *AccountPostgres) IsRemovedByUsername(username string) (bool, error) {
	isRemoved, err := r.queries.IsAccountRemovedByUsername(context.Background(), username)
	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isRemoved, nil
}

func (r *AccountPostgres) IsRemovedByID(id int32) (bool, error) {
	isRemoved, err := r.queries.IsAccountRemovedByID(context.Background(), id)
	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isRemoved, nil
}

func (r *AccountPostgres) RemoveAccount(id int32) error {
	if err := r.queries.RemoveAccount(context.Background(), id); err != nil {
		exloggo.Error(err.Error())
		return err
	}

	return nil
}

func (r *AccountPostgres) ReplaceRoles(id int32, roles []string) error {
	if err := r.queries.DeleteAccountRoles(context.Background(), id); err != nil {
		exloggo.Error(err.Error())
		return err
	}

	for _, role := range roles {
		_, err := r.queries.AppendRoleAccount(context.Background(), queries.AppendRoleAccountParams{
			Account: id,
			Role:    role,
		})
		if err != nil {
			exloggo.Error(err.Error())
			return err
		}
	}

	return nil
}

func (r *AccountPostgres) GetList(start, count int32) ([]queries.GetExistAccountsRow, error) {
	accounts, err := r.queries.GetExistAccounts(context.Background(), queries.GetExistAccountsParams{
		Offset: start,
		Limit:  count,
	})
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return accounts, nil
}

func (r *AccountPostgres) Update(updatedAccount *models.Account) error {
	if err := r.queries.UpdateAccount(context.Background(), queries.UpdateAccountParams{
		Username: updatedAccount.Username,
		Password: updatedAccount.Password,
		Balance:  updatedAccount.Balance,
		ID:       updatedAccount.ID,
	}); err != nil {
		exloggo.Error(err.Error())
		return err
	}

	return nil
}

func (r *AccountPostgres) BlockToken(token string) error {
	if err := r.queries.AppendTokenToBlackList(context.Background(), token); err != nil {
		exloggo.Error(err.Error())
		return err
	}

	return nil
}

func (r *AccountPostgres) IsContainBlackListToken(token string) (bool, error) {
	isContain, err := r.queries.IsContainBlackListToken(context.Background(), token)
	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isContain, err
}

func (r *AccountPostgres) AppendRole(id int32, role string) error {
	_, err := r.queries.AppendRoleAccount(context.Background(), queries.AppendRoleAccountParams{
		Account: id,
		Role:    role,
	})
	if err != nil {
		exloggo.Error(err.Error())
	}
	return err
}

func (r *AccountPostgres) GetRoles(id int32) ([]string, error) {
	roles, err := r.queries.GetAccountRoles(context.Background(), id)
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return roles, nil
}

func (r *AccountPostgres) GetByID(id int32) (*queries.Account, error) {
	account, err := r.queries.GetAccountByID(context.Background(), id)
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return &account, nil
}

func (r *AccountPostgres) GetByUsername(username string) (*queries.Account, error) {
	account, err := r.queries.GetAccountByUsername(context.Background(), username)
	if err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return &account, nil
}

func (r *AccountPostgres) IsExistByID(id int32) (bool, error) {
	isExist, err := r.queries.IsAccountExistByID(context.Background(), id)

	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isExist, nil
}

func (r *AccountPostgres) IsExistByUsername(username string) (bool, error) {
	isExist, err := r.queries.IsAccountExistByUsername(context.Background(), username)

	if err != nil {
		exloggo.Error(err.Error())
		return false, err
	}

	return isExist, nil
}

func (r *AccountPostgres) CreateUser(username, password string, balance float64) (*queries.Account, error) {
	return r.create(username, password, constants.RoleUser, balance)
}

func (r *AccountPostgres) CreateAdmin(username, password string, balance float64) (*queries.Account, error) {
	return r.create(username, password, constants.RoleAdmin, balance)
}

func (r *AccountPostgres) create(username, password, role string, balance float64) (*queries.Account, error) {
	var account *queries.Account

	if err := r.ExecuteWithTransaction([]TXQuery{
		func(tx *queries.Queries) error {
			dbAccount, err := tx.CreateAccount(context.Background(), queries.CreateAccountParams{
				Username: username,
				Password: password,
				Balance:  balance,
			})
			if err != nil {
				exloggo.Error(err.Error())
				return err
			}

			account = &dbAccount

			return nil
		},
		func(tx *queries.Queries) error {
			_, err := tx.AppendRoleAccount(context.Background(), queries.AppendRoleAccountParams{
				Account: account.ID,
				Role:    role,
			})
			if err != nil {
				exloggo.Error(err.Error())
				return err
			}
			return nil
		},
		func(tx *queries.Queries) error {
			if role == constants.RoleUser {
				return nil
			}

			_, err := tx.AppendRoleAccount(context.Background(), queries.AppendRoleAccountParams{
				Account: account.ID,
				Role:    constants.RoleUser,
			})
			if err != nil {
				exloggo.Error(err.Error())
				return err
			}
			return nil
		},
	}); err != nil {
		exloggo.Error(err.Error())
		return nil, err
	}

	return account, nil
}

func NewAccountPostgres(queries *queries.Queries, db *sql.DB) *AccountPostgres {
	return &AccountPostgres{queries: queries, db: db}
}
