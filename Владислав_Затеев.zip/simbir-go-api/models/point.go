package models

type Point struct {
	Longitude float64
	Latitude  float64
}
