package models

type PaymentHesoyamUserOutput struct {
	Account GetAccountOutput
}

type PaymentHesoyamAdminOutput struct {
	Account AdminGetAccountOutput
}
