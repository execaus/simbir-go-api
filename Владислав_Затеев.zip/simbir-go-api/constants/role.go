package constants

const (
	RoleUser  = "USER"
	RoleAdmin = "ADMIN"
)
